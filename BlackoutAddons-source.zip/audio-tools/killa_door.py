"""Original 'someone pounding on a heavy metal door' for Killa's entrance (no outside recordings).
Rhythm and tone modelled on the reference the user liked: two bursts of fast pounding, dark steel-door sound."""
import numpy as np, soundfile as sf
from scipy import signal
import make_audio as A
SR = A.SR
rng = np.random.default_rng(11)
REF = "./killa_door_A.wav"

DOOR = [(78, .22), (112, .20), (171, .16), (238, .13), (331, .11), (452, .09), (618, .07), (835, .05), (1130, .035), (1520, .025)]

def hit(power):
    n = int(0.45 * SR); t = np.arange(n) / SR
    y = np.zeros(n)
    for f, d in DOOR:
        f2 = f * (1 + 0.02 * rng.uniform(-1, 1))
        y += rng.uniform(0.5, 1.0) * np.sin(2 * np.pi * f2 * t + rng.uniform(0, 6.3)) * np.exp(-t / (d * rng.uniform(0.8, 1.2)))
    thump = np.sin(2 * np.pi * (60 + 45 * np.exp(-t / 0.02)) * t) * np.exp(-t / 0.07) * 1.6     # fist/boot on the panel
    slap = A.butter(rng.normal(0, 1, n), lo=300, hi=2500) * np.exp(-t / 0.012) * 0.8
    rattle = A.butter(rng.normal(0, 1, n), lo=1500, hi=4500) * np.exp(-t / 0.05) * 0.12 * (rng.random() < 0.5)   # loose frame
    return (y * 0.55 + thump + slap + rattle) * power

def burst(dur, start_pow, end_pow):
    n = int((dur + 0.6) * SR); x = np.zeros(n); tt = 0.0
    while tt < dur:
        p = np.interp(tt, [0, dur], [start_pow, end_pow]) * rng.uniform(0.55, 1.0)
        h = hit(p); i = int(tt * SR); m = min(len(h), n - i); x[i:i + m] += h[:m]
        tt += rng.choice([0.07, 0.075, 0.08, 0.09, 0.1, 0.12, 0.14], p=[.22, .18, .18, .14, .12, .1, .06])
    return x

def match_eq(x, ref):
    """same long-term tone as the reference"""
    f, Px = signal.welch(x, SR, nperseg=4096); _, Pr = signal.welch(ref, SR, nperseg=4096)
    g = np.sqrt((Pr + 1e-12) / (Px + 1e-12)); g = np.clip(g / np.median(g[(f > 80) & (f < 1500)]), 0.05, 6.0)
    g = signal.savgol_filter(g, 31, 2); g = np.clip(g, 0.03, 6.0)
    taps = signal.firwin2(1025, f / (SR / 2), g)
    return signal.fftconvolve(x, taps, mode="same")

def build():
    a = burst(1.9, 0.35, 0.55)
    b = burst(2.45, 0.6, 1.0)
    x = np.concatenate([a[:int(2.1 * SR)], np.zeros(int(0.55 * SR)), b])
    x = A.reverb(x, rt60=1.1, wet=0.22, bright=3000)[:len(x)]
    ref, _ = sf.read(REF)
    x = match_eq(x, ref)
    x = np.tanh(x / np.max(np.abs(x)) * 1.3)
    x = A.fade(A.trim_tail(x, 1e-3), 0.003, 0.5)
    return x / np.max(np.abs(x)) * 0.95

if __name__ == "__main__":
    import sys
    y = build()
    sf.write("./killa_door_original.wav", y, SR, subtype="PCM_16")
    if "game" in sys.argv: sf.write("final/killa_hatch.wav", y, SR, subtype="PCM_16")
    print(len(y) / SR)
