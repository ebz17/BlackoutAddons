# 1.24.0: sewage conduit breach (Killa breaks in). Same voice/PA chain as voices_v4.
import sys, importlib.util
import faults as F
from voices_v2 import EN, RU
sys.argv = ['x', 'none']
spec = importlib.util.spec_from_file_location("m", "/home/claude/audio/match_pa.py"); M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
LINES = {
    "vo_conduit_breach": ("Attention, security! Breach in the sewage conduit. Intruders on the lower level.",
                          "Внимание, охрана! Взломан люк канализации. Проникновение на нижнем уровне."),
}
import parselmouth
from parselmouth.praat import call
def younger(path_in, path_out):
    snd = parselmouth.Sound(path_in); snd.scale_peak(0.7)
    f0 = call(snd.to_pitch(), "Get quantile", 0, 0, 0.5, "Hertz")
    out = call(snd, "Change gender", 75, 600, 1.06, f0 * 1.10, 1.15, 1.0)
    out.save(path_out, "WAV")
for name, (en, ru) in LINES.items():
    for lang, text, model, scale in (("en", en, EN, 1.02), ("ru", ru, RU, 0.98)):
        raw = f"/home/claude/audio/raw/{name}_{lang}.wav"
        F.tts(text, model, raw, scale)
        young = f"/home/claude/audio/raw/{name}_{lang}_young.wav"
        younger(raw, young)
        F.write(f"{name}_{lang}", M.labs_pa(young), 0.8)
