# Public-domain English PA voice (Piper LJSpeech - dataset is public domain), same Labs PA chain.
import sys, importlib.util, parselmouth
from parselmouth.praat import call
import faults as F
from voices_v2 import LINES as L2
sys.argv = ['x', 'none']
spec = importlib.util.spec_from_file_location("m", "./match_pa.py"); M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
EN = "./voices/en_US-ljspeech-high.onnx"
L4 = {
    "vo_emergency_on": "Attention, personnel! Emergency power activated. Hangar and parking gates are open. Battery reserve is limited.",
    "vo_emergency_low": "Warning! Emergency battery reserve: one minute remaining.",
    "vo_emergency_out": "Attention, personnel! Emergency power depleted. All gates are closed.",
    "vo_control_repaired": "Attention, personnel! Generator control repaired. Main generator ready to start.",
}
lines = {k: v[0] for k, v in L2.items()}
lines.update(L4)
def pa(path_in, path_out):
    snd = parselmouth.Sound(path_in); snd.scale_peak(0.7)
    f0 = call(snd.to_pitch(), "Get quantile", 0, 0, 0.5, "Hertz")
    out = call(snd, "Change gender", 75, 600, 1.0, f0 * 1.03, 1.1, 1.0)   # LJ is already a younger female voice: light touch
    out.save(path_out, "WAV")
only = sys.argv[1:] if len(sys.argv) > 1 and sys.argv[1] != 'none' else None
for name, text in lines.items():
    raw = f"./raw/{name}_en_lj.wav"
    F.tts(text, EN, raw, 1.0)
    tuned = f"./raw/{name}_en_lj2.wav"
    pa(raw, tuned)
    F.write(f"{name}_en", M.labs_pa(tuned), 0.8)
