Blackout x Black Division  v1.5.0  (SPT 4.1.x)
================================================
Brings back Wedge + Black Division guards in Blackout Labs raids.

Requires (server side):
  - Blackout 4.1.1+            (user/mods/Blackout)
  - WTT Black Division 1.3.x   (user/mods/BlackDivServer)

How it works
  Blackout decides blackout / normal for the NEXT raid on server start and after every raid.
  When you start a Labs raid, this mod checks that roll just before SPT builds the raid:
    BLACKOUT -> Black Division's random Wedge spawn is swapped for a guaranteed
                Wedge + 4 Black Division (blackDivIb) guards.
    normal   -> nothing changes; Black Division keeps its own labsStartChance roll
                (unless wedgeOnlyDuringBlackout = true).
  Black Division's gate (exfil) events are never touched.

Generator room spawn (spawnInGeneratorRoom = true, default)
  The blackout Wedge group is sent to the basement zone; the Blackout Power Restore client mod
  puts them in the generator room, and then they move out and hunt. Without the client mod they
  spawn somewhere in the basement. false = use spawnZones.

Wedge carries Blackout's key (wedgeCarriesKey = true, default)
  In blackout raids Wedge always has Blackout's key on him: it opens the locked medical corridor
  door to the room with the gate switch and the code whiteboard. Blackout's own key on the desk
  still spawns too.

Labs keycards (keycardChance = 25, default)
  In blackout raids each Black Division soldier (not Wedge - he has the key) has a 25% chance of
  one Labs keycard in his pockets: access card most often, red and black rarely. Includes the
  second wave from the client mod. Change the chance or the list ("keycards") in config.jsonc.
  0 = off. Normal loot is back from the next raid.

Killa (killaEnabled = true, default)
  In blackout raids Killa comes in alone through the sewage conduit. killaAfterBlackDivision = true
  (default): he is the surprise final boss - the Blackout Power Restore client mod holds him back until
  Black Division is wiped out (backup time in its config). false = random time between
  killaMinMinutes and killaMaxMinutes. killaChance = 0-100.

Config: config.jsonc (re-read every Labs raid, no restart needed).

Console lines to look for:
  [Blackout] Roll: BLACKOUT this raid.
  [Blackout x BlackDiv] BLACKOUT raid - Wedge (100% chance) + 4 Black Division guards added to Labs.
