Blackout Power Restore  v1.27.10  (client, SPT 4.1.x)
====================================================
Restart the facility's generators during a Blackout Labs raid.

Requires: Blackout (BepInEx/plugins/Blackout.dll)

Raid start (surprise)
  Looks like a completely normal Labs raid: all normal extracts listed and working.
  Only when the power actually cuts do the normal exits lock and the list switches to the
  emergency gates. (Config "Surprise blackout" off = Blackout's default, locked from the start.)

While the power is out
  - Generator switch: boiler control panel in the basement generator room (blinking red light).
  - Battery emergency lamps stutter, drop out or brown out now and then.
  - Keycard readers are dead. No emergency code either (config "Emergency code", off by default).

Starting the generators
  - Two 600 kVA V12 generators. Generator A starts first (air start, can fail and need
    another try), the siren winds up and red beacons spin; lights come back in waves.
  - Generator B starts a few seconds later and syncs with a breaker clunk -> full power:
    all lights, all normal extracts, keycards work, PA "main power has been restored".

Generator B trip (chance in config)
  - B trips its breaker during sync: bang, arc, it shuts down.
  - PARTIAL POWER: only the half of Labs on generator A's side has light, its extracts work
    and its keycard readers work. The other half stays on emergency lamps, its extracts stay
    locked and its card readers say "No power".
  - In the switchgear room next door, the tripped breaker has a blinking yellow light, buzz and
    spark. Use each one ("Reset tripped breaker").
  - Then flip the generator switch ("Restart generator B"). Before that, the PA refuses:
    "distribution fault, generator B start blocked".

Burnt-out generator control (chance in config, default 35% per start attempt)
  - Instead of starting, the generator switch shorts out: a bang, sparks, then it keeps
    buzzing and sparking. It is broken for the rest of the raid - the facility stays dark.
  - PA: "Main generator control failure. Due to technical problems, the facility will remain
    without main power." The red beacons in the generator room keep turning.
  - False starts (every ~1.5 min of darkness): the generators try on their own. The engine catches roughly,
    hunts up and down and misfires; the lights struggle up and follow it (pulsing, flickering on
    every misfire). After 15-30 s (random) it either stalls (coughs, backfire, dies) or trips the main breaker
    (bang, engine flares, shuts down). Near the generators you hear the engine; when the lights die,
    Blackout's own power-down sound plays. Extracts and keycard readers stay dead.
  - Way out: Wedge's key on the gate switch (emergency power, a few minutes), the repair kit, or the
    sewage conduit once Killa has broken in.

Breaker failure later on (chance in config)
  - Some minutes after full power (3-10 min by default) the sector B breaker can trip on its own.
  - Sector B goes dark: its extracts lock, its card readers say "No power", orange emergency
    lamps come on. The PA warns: "distribution fault in sector B, automatic reclosing".
  - Auto-reclose keeps trying: every 20-40 s the lights come back for a few seconds, then trip
    again - forever, until you reset the breaker cabinet in the switchgear room by hand.

Flicker ("Flicker amount" 0-2)
  - Messier start-up: late tubes, struggling tubes, more flashes.
  - Old tubes near you stutter now and then while powered.
  - Emergency lamps flicker more often.

Black Division (needs the server mod BlackoutBlackDivision 1.5.0)
  - On blackout raids Wedge and his guards are the reason the lights go out (config
    "Black Division arrives"):
      BeforeTheBlackout (default): they arrive in the basement generator room at raid start.
        Blackout's countdown waits until the whole group is in; a few seconds later you hear the
        generators being shut down - and the lights go out.
      AfterTheBlackout: the lights go out first, they arrive ~5 s later.
    If you spawn within ~40 m of the generator room, they come in at a spawn point at least 70 m away from you (basement first).
    All other bots spawn as normal.
  - They start hunting a few seconds after the lights go out.
  - They don't guard the room: about 10 s later they move out and hunt whoever is closest -
    you, PMC bots, scavs or raiders. The first order is fairly accurate (~6 m), then every
    30-60 s they get a rougher idea (~15 m) of where their nearest target is.
  - In blackout raids they are hostile to everyone (no "warn first" for USECs or scavs) and
    everyone fights back. Config "Black Division hostile to everyone" off = Black Division's own rules.
  - With SAIN installed the orders go through SAIN, so they really go.
  - "Black Division really hunts (restart)" (on, needs BigBrain): Black Division runs the game's raider
    brain, which picks a spot and holds it. In blackout raids its raider "hold" layer is taken out and a small hunt
    layer walks them to where the hunt orders send them, until they see or hear someone (then SAIN fights).
  - They spawn once per raid. Switching the power off/on never spawns them again.
  - Stuck guard: one that hasn't moved for 2 min (40 s right after spawning; sees nobody, you 40+ m away) is moved a couple of metres
    to free floor (config "Unstick Black Division").
  - Second wave (config "Second wave", on by default): once per raid, when you get full power back
    or open the gates with the key (whichever comes first), Black Division come back in about
    30 s later (3 by default), with the PA "intruders" line, somewhere in Labs 60-160 m from you.
    They hunt like the first team.
    Config: "Second wave size (min)" / "(max)", "Second wave delay (s)".
  - Gate squad (1.27.4, config "Gate squad", on by default): when you open the gates with Wedge's key,
    Black Division sends soldiers in through them (2 by default: one at the hangar gate, one at the parking gate),
    about 15 s later. They don't hunt: they hold their gate for the rest of the raid, fight anyone they see,
    and walk back to their post afterwards. If you're standing at a gate they wait (max 45 s) so nobody pops up
    in front of you. This comes on top of the second wave. Config: "Gate squad size" (1-6).
    The gate squad doesn't hold Killa back: he breaks in once the hunting Black Division are dead (1.27.5).
  - The Stalker (separate mod, 1.0.15+): every light around him dies as he moves (BlackoutApi.DarkPresence, 1.27.6:
    all lights, by shrinking their reach - never their on/off state, so power cuts and restores are never affected).
    1.27.9: also the facility's own tube and panel lights (most of Labs at full power), and on every map he visits.
    1.27.10: The Stalker 1.0.37+ can shut the generators down at the switch (BlackoutApi 3). The raid summary shows
    "the Stalker cut the power".
  - Gates and main power (1.27.6): with main power on (full, or half on the gate's side) the gates' own switches work
    again - open them the normal way. Wedge's key on main power opens them with no time limit; the emergency batteries
    only start if the power goes while they're open (and pause again when it comes back). A gate opened the normal way
    closes on a power cut and reopens when the power is back. Opening a gate either way brings the gate squad.
  - Each Black Division soldier (not Wedge) may carry a Labs keycard (server mod config "keycardChance").

Emergency power, repair kit, sewage conduit (1.20.0, config section "6. Emergency and repair")
  - No emergency code: no power, nothing works. Blackout's keypad and whiteboard are gone.
  - Wedge's key on the gate switch = emergency batteries: both gates and the parking door open, the PA
    warns at 1 minute left and a red countdown stays on screen. After 3 min the batteries are flat: the gates close and even the
    emergency lamps die. Only real power brings the gates back.
    While it lasts, the same red rotating beacons as in the generator room turn on the ceilings of the
    main rooms, at both gates and in the gate switch room (config "Warning beacons"); they go out with the batteries.
  - Repair kit for a burnt generator control: Toolset + Spark plug + 2x Bundle of wires.
      Toolset and wires: on the floor by the computers in the room with the most PCs.
      Spark plug: in the pockets of one of Wedge's guards.
    Use the burnt switch with the parts in your inventory and stay next to it for 12 s. The plug and
    wires are used up (you keep the toolset). The next start works for sure: 50% both generators,
    50% only generator A (B is damaged for the rest of the raid - half the extracts and doors).
    Shut it down again and you're back to the Brutal odds - bad idea.
  - Sewage conduit: opens for good the moment Killa breaks the hatch.
  - Ctrl+F5 also shows the nearest repair part, who has the spark plug, and the emergency power left.

Killa - surprise final boss (needs the server mod BlackoutBlackDivision 1.5.0)
  - Blackout raids: Killa is held back until Black Division is wiped out (Wedge, his guards and the
    second wave if it is on its way - not the extra squads Black Division's own mod sends to the gates). 30-60 s after the last one dies you may hear him banging on
    the sewage conduit door (quiet; faint at ~85-110 m) before he gets in and screams.
  - Backup: if Black Division is still alive at 25 min (config "Killa backup time (min)") he comes anyway.
  - "Killa stalks you" (on): every 45-90 s he goes after someone - every other time you, otherwise
    whoever is closest (PMCs, Black Division, raiders). Hostile to all of them, both ways.
  - Optional: stand where he should come in and press Ctrl+Shift+F8. Ctrl+F5 shows where he is.

Shutting down
  - At full power the switch shuts both generators down and the facility goes dark again.

Switchgear room
  By default the breaker is the cabinet at -232.741, -2.442, -295.317 (1 fault).
  Ctrl+F7 while looking at a cabinet makes it THE breaker cabinet (replaces the old one).
  Optional: Ctrl+Shift+F7 adds extra cabinets (one is picked at random each time).

Placement keys
  Ctrl+F9   generator switch      (default: boiler control panel, basement)
  Ctrl+F11  generator A / B       (default: the two basement generators)
  Ctrl+F7   breaker cabinet       (Ctrl+Shift+F7 adds an extra one)
  Ctrl+F8   Black Division spawn  (stand on the spot; default: automatic in the generator room)
  Ctrl+Shift+F8   Killa spawn  (stand on the spot; default: the sewage conduit)
  Ctrl+F5   Where are Killa (or his body) and the nearest Black Division (testing)
  Ctrl+F2   Add a repair part spot where you stand (toolset / wires go on random spots from your list)
  Ctrl+Shift+F2   Clear your repair part spots (back to automatic: by the computers)
  Ctrl+F3   Add an emergency beacon spot where you stand (red beacon on the ceiling above)
  Ctrl+Shift+F3   Clear your beacon spots (back to automatic)

Config: F12 menu or BepInEx/config/com.blackoutaddons.powerrestore.cfg

Labs announcer
  - The mod's PA lines use the Labs announcer style: "Attention, personnel! ...", no chime.
  - The game's own announcer (from your game files, nothing is shipped) for the power cut
    ("lights out") and, when Black Division cuts it, "Attention, security! Unauthorized activity
    in sector B-11". Settings "Game voice: ..." (section 4).
  - One announcement per event. The PA never talks over itself: lines wait their turn with a
    ~3 s pause, and a line that would wait more than ~10 s is dropped as out of date.
  - Breaker blocked / breakers reset: short sound cues at the switch instead of announcements.
  - Ctrl+F6: how far and which way Blackout's gate switch and code whiteboard are. The gate
    switch has a small blinking green lamp.

Sounds: plain WAV files in the sounds folder - replace any with your own (same name).

Compatibility
  - SAIN: Black Division hunt orders go through SAIN's squad search.
  - MoreBotsAPI 2.1.x: fixes its HuntManager NullReference for bots spawned without spawn
    params (QuestingBots PMCs). Without the fix QuestingBots logs "Could not finish activation".

Balance (1.17.1, "brutal blackout" - applied once to existing config files too)
  Getting the power back is rare (~37% of raids); most of the time the switch burns out and the way
  out is Wedge's key and the gates.
    Failed start chance 70%, up to 4 failed starts, switch burnout 35% per attempt
    Generator B trip 85%, 2 cabinets to reset, breaker failure later 85% (3-10 min)
  Hard:   burnout 25, failed start 60, max fails 3, trip 70, breaker failure 70 (~56% get power)
  Easier: burnout 15, failed start 40, max fails 2, trip 50, cabinets 1, breaker failure 50 (~78% get power)
